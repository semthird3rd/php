package com.example.myapplication


import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val userNameEditText = findViewById<EditText>(R.id.editTextUserName)
        val passwordEditText = findViewById<EditText>(R.id.editTextPassword)
        val validateButton = findViewById<Button>(R.id.buttonValidate)

        validateButton.setOnClickListener {
            val userName = userNameEditText.text.toString()
            val password = passwordEditText.text.toString()

            // Assuming "YourName" as the username and "YourPassword" as the password for validation
            if (userName == "raj" && password == "raj") {
                Toast.makeText(this, "Valid Credential", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Wrong Credential", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
