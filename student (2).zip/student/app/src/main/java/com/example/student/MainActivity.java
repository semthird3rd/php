package com.example.student;


import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final EditText rollNoEditText = findViewById(R.id.rollNoEditText);
        final EditText nameEditText = findViewById(R.id.nameEditText);
        final EditText mobileNoEditText = findViewById(R.id.mobileNoEditText);
        Button submitButton = findViewById(R.id.submitButton);
        final TextView displayTextView = findViewById(R.id.displayTextView);

        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Getting the entered text from EditTexts
                String rollNo = rollNoEditText.getText().toString();
                String name = nameEditText.getText().toString();
                String mobileNo = mobileNoEditText.getText().toString();

                // Displaying the entered information
                String displayText = "Roll No: " + rollNo + "\nName: " + name + "\nMobile No: " + mobileNo;
                displayTextView.setText(displayText);
            }
        });
    }
}
